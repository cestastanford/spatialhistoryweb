The Rise in the American Railway Union, 1893-1894

Data file:
Unions_GIS_Master.xls

Description:

This Excel spreadsheet is the one used in creating the visualization.  It demonstrates the changes within each American Railway Union chapter from 1893 to 1894.  The names of the secretaries, union numbers, and address locations are exactly as they appear in the primary source (see below).  The other categories are also the same as in the primary source, but have been rearranged for easier import into ArcGIS and the visualization.  The original tables are also available.  This format of the data is preferable for analysis because it allows immediate comparison of each union over time instead of across several tables.

Origin of the Data:

The American Railway Union, Railway Times, Volume I. Chicago: American Railway Union, 1894.  Membership information can be found in the last pages of each month�s American Railway Union newspaper (Railway Times).  This book is a bound copy of all the newspapers published by the union in 1894.

More Information:

If you have further questions or need more information, please contact the Spatial History Lab at spatialhistory@gmail.com and Evgenia Shnayder at evgenia.shnayder@gmail.com. 

Links:

http://www.stanford.edu/group/spatialhistory/cgi-bin/site/viz.php?id=139&project_id=0

Access and use limitations:

The reuse and adaptation of this data is encouraged for scholarly work. Its commercial use is strictly prohibited. Kindly inform the authors of any adaptations or modifications made to improve the quality of the data.
