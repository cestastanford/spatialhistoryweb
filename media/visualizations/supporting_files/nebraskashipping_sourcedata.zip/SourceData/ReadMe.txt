Union Pacific Shipping from Nebraska: Forwarded/Received/East/West

Data File:
UP_Shipping.csv

Description:

This Excel sheet comes from the original primary source (see below), and with the exception of the abbreviated column headings and last six columns, is exactly the same as the source.  The two documents show railroad traffic along various Union Pacific stations in 1893.  The abbreviations in the headings stand for the following:
R: received (as in goods received)
EB: eastbound (as in eastbound goods)
WB: westbound (as in westbound goods)
TF: total forwarded (as in goods forwarded, not be to confused with �Total Forwarded,� which indicates how many goods in total that station forwarded)  This category did not exist in the original source, and is a summation of all of the goods forwarded at each station.
D: difference.  This category did not exist on the original document and is an in-lab calculation of the number of goods (and which kind) that were either added to the Union Pacific from other and smaller railroad lines, or lost by the Union Pacific to nearby smaller railroad lines.

Origin of the Data:

Nebraska State Museum and Archives, Lincoln. MS 3761, 56:192 Series 1 Box 1, Pages 74, 78. 

More Information:

If you have further questions or need more information, please contact the Spatial History Lab at spatialhistory@gmail.com and Evgenia Shnayder at evgenia.shnayder@gmail.com.

Links:

"Union Pacific Shipping from Nebraska: Forwarded/Received"
http://www.stanford.edu/group/spatialhistory/cgi-bin/site/viz.php?id=257&project_id=0

"Union Pacific Shipping from Nebraska: East/West"
http://www.stanford.edu/group/spatialhistory/cgi-bin/site/viz.php?id=255&project_id=0


Access and use limitations:

The reuse and adaptation of this data is encouraged for scholarly work. Its commercial use is strictly prohibited. Kindly inform the authors of any adaptations or modifications made to improve the quality of the data.
