California Railroad Commission, Station Construction Data, 1850-1900

Data file:
Description Railroads 1894.xls

Description:

The first three columns are from the original primary source (see below).  The construction dates originated from the �Description of Road� categories in the California Railroad Annual Reports.  The reason that the data is from 1894 and not from 1900 is due to the fact that the California Railroad Annual Reports stopped reporting railroad construction dates in 1894.  The last two columns are notes from the Spatial History Lab�they explain why we have or have not added some construction dates to our visualization.  These notes are updated as we update the visualization.

Origin of the Data:

State Office, Report of the Board of Railroad Commissioners (First Biennial) of the State of California. 1893-1894. Sacramento, California: A.J. Johnson, Supt. State Printing, 1894.  Various pages (each railroad company reported their rail line construction dates in their respective annual reports).

More Information:

If you have further questions or need more information, please contact the Spatial History Lab at spatialhistory@gmail.com and Evgenia Shnayder at evgenia.shnayder@gmail.com.

Links:

http://www.stanford.edu/group/spatialhistory/cgi-bin/site/viz.php?id=97&project_id=0

Access and use limitations:

The reuse and adaptation of this data is encouraged for scholarly work. Its commercial use is strictly prohibited. Kindly inform the authors of any adaptations or modifications made to improve the quality of the data.
