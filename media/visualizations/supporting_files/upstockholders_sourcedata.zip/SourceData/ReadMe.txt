Distribution of Union Pacific Stockholders by City (1869)

Data file:
Stockholder Shares.csv

Description:

The original primary source (see below) listed the names of Union Pacific stockholders in 1869, their addresses, and the number of shares they owned in the company.  This Excel sheet splits the name into two categories: first name and last name, and separates the address into city, state, and state abbreviation categories.  The names may be incorrectly spelled due to difficulties reading the original document in certain sections.  This Excel sheet is the one that was used in creating the visualization and importing the data into ArcGIS.

Origin of the Data:

Union Pacific, �List of Stockholders of the Union Pacific Rail Road Co. with place of residence and amount of stock standing in name of each, Jany 1869.�  Grenville M. Dodge Papers, MS 98, State Historical Society of Iowa.

More Information:

If you have further questions or need more information, please contact the Spatial History Lab at spatialhistory@gmail.com and Evgenia Shnayder at evgenia.shnayder@gmail.com.

Links:

http://www.stanford.edu/group/spatialhistory/cgi-bin/site/viz.php?id=117&

Access and use limitations:

The reuse and adaptation of this data is encouraged for scholarly work. Its commercial use is strictly prohibited. Kindly inform the authors of any adaptations or modifications made to improve the quality of the data.
